const inpArr = document.getElementsByTagName("input");
const btnArr = document.getElementsByTagName("button");
const retDivArr = document.getElementsByClassName("returnDiv");
const retField = document.getElementById("returnField");

let timerId = setTimeout(null, 2000);


const consultSelect = document.getElementById("consultSelect");
consultSelect.onchange = (() => {
    const consultBtn = document.getElementById("consultBtn");
    if (consultSelect.options.selectedIndex === 0)
        consultBtn.removeAttribute("hidden");
    else
        consultBtn.setAttribute("hidden", "");
    makeTimer();
});

inpArr[4].addEventListener('input', makeTimer);

function consult() {  
    Array.from(retDivArr).forEach((currElem) => {
        while (currElem.childElementCount > 1)
            currElem.removeChild(currElem.lastChild);
    });

    switch (consultSelect.options.selectedIndex) {
        case 0:
            fetch(`/consult-id?id=${inpArr[4].value}`)
                .then(function (response) {
                    return response.json();
                })
                .then(function (myJson) {
                    addToHtml(myJson);
                });
            break;
        case 1:
            fetch(`/consult-name?name=${inpArr[4].value}`)
                .then(function (response) {
                    return response.json();
                })
                .then(function (myJson) {
                    addToHtml(myJson);
                });
            break;
        case 2:
            fetch(`/consult-email?email=${inpArr[4].value}`)
                .then(function (response) {
                    return response.json();
                })
                .then(function (myJson) {
                    addToHtml(myJson);
                });
            break;
    }
}

function add() {
    fetch(`/addusr`, { 
        method: 'POST',
        body: JSON.stringify({
            id: inpArr[0].value,
            name: inpArr[1].value,
            email: inpArr[2].value
        }),
        headers: {
            "Content-type": "application/json; charset=UTF-8"
        }
    })
}

function del() {
    const deleteSelect = document.getElementById("deleteSelect");
    typeChoice = (deleteSelect.options[deleteSelect.options.selectedIndex].value).toString().toLowerCase();
    inputChoice = (inpArr[3].value).toString().toLowerCase();
    fetch(`/delusr`, { 
        method: 'DELETE',
        body: JSON.stringify({
            type: typeChoice,
            input: inputChoice
        }),
        headers: {
            "Content-type": "application/json; charset=UTF-8"
        }
    })
}

function addToHtml(jsonObj) {
    jsonObj.forEach(jsonElem => {
        retDivArr[0].insertAdjacentHTML("beforeend", "<div>" + jsonElem.id + "</div>");
        retDivArr[1].insertAdjacentHTML("beforeend", "<div>" + jsonElem.name + "</div>");
        retDivArr[2].insertAdjacentHTML("beforeend", "<div>" + jsonElem.email + "</div>");
    }); 
}

function makeTimer(){
    clearInterval(timerId);
    if (consultSelect.options.selectedIndex === 0 || inpArr[4].value.length < 4)
        return;
    timerId = setTimeout(consult, 2000);
}

function show(which) {
    const toShow = document.getElementsByClassName(which);
    for (let i=0; i<toShow.length; i++) {
        toShow[i].removeAttribute("hidden");
    }
}