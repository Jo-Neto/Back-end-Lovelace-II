const inpElem = document.getElementsByTagName("input")[0];
const selected = document.getElementsByTagName("select")[0];
const retDivArr = document.getElementsByClassName("returnDiv");
const btnElem = document.getElementsByTagName("button")[0];
const retField = document.getElementById("returnField");

let timerId = setTimeout(null, 2000);

selected.onchange = (() => {
    if (selected.options.selectedIndex === 0)
        btnElem.removeAttribute("hidden");
    else
        btnElem.setAttribute("hidden", "");
    makeTimer();
});

inpElem.addEventListener('input', makeTimer);

function consult() {  
    Array.from(retDivArr).forEach((currElem) => {
        while (currElem.childElementCount > 1)
            currElem.removeChild(currElem.lastChild);
    });

    switch (selected.options.selectedIndex) {
        case 0:
            fetch(`/consult-id?id=${inpElem.value}`)
                .then(function (response) {
                    return response.json();
                })
                .then(function (myJson) {
                    addToHtml(myJson);
                });
            break;
        case 1:
            fetch(`/consult-name?name=${inpElem.value}`)
                .then(function (response) {
                    return response.json();
                })
                .then(function (myJson) {
                    addToHtml(myJson);
                });
            break;
        case 2:
            fetch(`/consult-email?email=${inpElem.value}`)
                .then(function (response) {
                    return response.json();
                })
                .then(function (myJson) {
                    addToHtml(myJson);
                });
            break;
    }
}

function addToHtml(jsonObj) {
    jsonObj.forEach(jsonElem => {
        retDivArr[0].insertAdjacentHTML("beforeend", "<div>" + jsonElem.id + "</div>");
        retDivArr[1].insertAdjacentHTML("beforeend", "<div>" + jsonElem.name + "</div>");
        retDivArr[2].insertAdjacentHTML("beforeend", "<div>" + jsonElem.email + "</div>");
    });
}

function makeTimer(){
    clearInterval(timerId);
    if (selected.options.selectedIndex === 0 || inpElem.value.length < 4)
        return;
    timerId = setTimeout(consult, 2000);
}