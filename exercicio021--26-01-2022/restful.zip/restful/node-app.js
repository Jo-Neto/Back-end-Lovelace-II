const express = require('express');

const application = express();

application.use(express.json());
application.use('/', express.static('static-user-side'));

let produto = [];

application.post('/produto', (req, res) => { //new product
    if (Number(produto.findIndex(indexFinder, req.body.id)) === -1) {
        produto.push(req.body);
    }
    else
        return;
    res.json(produto);
})

application.get('/produto/all', (req, res) => { //show all products
    res.json(produto);
})

application.route('/produto/:id')
    .get((req, res) => { //consult
        const data = produto.filter((el)=>{return (req.params.id == el.id)});
        res.json(data);
    })
    .delete((req, res) => { //delete id, return true if delete completes, or false 
        let index = produto.findIndex(indexFinder, req.params.id);
        if (index !== -1) {
            produto.splice(index, 1);
        } else
            res.statusCode = 404;
        res.json(produto);
    })
    .put((req, res) => { //load html asking for produt:id change name, false if no id
        let index = produto.findIndex(indexFinder, req.params.id);
        if (index !== -1) {
            produto[index].name = req.body.name;
        } else  
            res.statusCode = 404;
        res.json(produto);
    })

application.listen(80);

function indexFinder(el) {
    return el.id == this;
}