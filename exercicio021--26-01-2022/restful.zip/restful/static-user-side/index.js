const buttonArr = document.getElementsByTagName("button");
const inputArr = document.getElementsByTagName("input");
const resultField = document.getElementById("resultField");
const columnArr = document.getElementsByClassName("clm");
const torf = document.getElementById("torf");

for (let i = 0; i < buttonArr.length; i++) {
    buttonArr[i].addEventListener("click", () => {
        switch (buttonArr[i].name) {
            case 'getBtn':
                reqGetId();
                break;
            case 'delBtn':
                reqDelId();
                break;
            case 'postBtn':
                reqPost();
                break;
            case 'putBtn':
                reqPutId();
                break;
        }
    });
}

function reqGetId() {
    fetch(`/produto/${inputArr[0].value}`)
        .then(response => { return response.json(); })
        .then(jsonRes => { 
            addToHtml(jsonRes) 
        });
}

function reqDelId() {
    let didChange = null;
    fetch(`/produto/${inputArr[0].value}`, {
        method: 'DELETE'
    })
        .then(response => { 
            (response.status == 404) ? didChange = false: didChange = true;
            return response.json(); 
        })
        .then(jsonRes => { addToHtml(jsonRes, didChange); })
}

function reqPost() {
    fetch(`/produto`, {
        method: 'POST',
        body: JSON.stringify({
            id: inputArr[1].value,
            name: inputArr[2].value
        }),
        headers: {
            'Content-Type': 'application/json'
        }
    })
        .then(response => { return response.json(); })
        .then(jsonRes => addToHtml(jsonRes));
}

//=============================================================

function reqPutId() {
    let didChange = null;
    fetch(`/produto/${inputArr[1].value}`, {
        method: 'PUT',
        body: JSON.stringify({
            name: inputArr[2].value
        }),
        headers: {
            'Content-Type': 'application/json'
        }
    })
        .then(response => { 
            (response.status == 404) ? didChange = false: didChange = true;
            return response.json(); 
        })
        .then(jsonRes => {
            addToHtml(jsonRes, didChange); 
        });
}

function addToHtml(obj, hasWorked=null) {
    torf.innerHTML = "";
    columnArr[0].innerHTML = "<h2>ID</h2>";
    columnArr[1].innerHTML = "<h2>NAME</h2>";
    if (hasWorked === true)
        torf.innerHTML = "true";
    else if (hasWorked === false)
        torf.innerHTML = "false";
    resultField.insertAdjacentHTML("beforeend", '<br /><br /><br />');
    for (let i = 0; i < obj.length; i++) {
        let p = document.createElement("p");
        p.innerText = obj[i].id;
        columnArr[0].insertAdjacentElement("beforeend", p);
        let p2 = document.createElement("p");
        p2.innerText = obj[i].name;
        columnArr[1].insertAdjacentElement("beforeend", p2);
    }
}